import tkinter as tk
from tkinter import ttk
import pyodbc

# Dữ liệu mẫu cho danh sách món ăn
ds_mon_an = []

# Kết nối đến SQL Server bằng Windows Authentication
conn = pyodbc.connect(
    'DRIVER={SQL Server};'
    'SERVER=MSOKIU;'
    'DATABASE=QLMonAn;'
    'Trusted_Connection=yes;'
)
cursor = conn.cursor()

# Thực thi câu truy vấn SELECT
cursor.execute(
    """SELECT MaMonAn, TenMonAn, DonViTinh, DonGia, TenNhom
       FROM MonAn
       JOIN NhomMonAn ON MonAn.Nhom = NhomMonAn.MaNhom"""
)
print('Danh sách món ăn: ')

# Lấy dữ liệu và hiển thị
rows = cursor.fetchall()
for row in rows:
    ds_mon_an.append({
        "Ma": row[0], "Ten": row[1], "DonVi": row[2], "DonGia": row[3], "Nhom": row[4]
    })
    print(f"ID: {row[0]}, Tên: {row[1]}, Đơn vị: {row[2]}, Đơn giá: {row[3]}, Nhóm: {row[4]}")

# Đóng con trỏ
cursor.close()


