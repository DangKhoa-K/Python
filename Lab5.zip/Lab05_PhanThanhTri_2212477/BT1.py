import pyodbc

conn = pyodbc.connect(
    'DRIVER={SQL Server};'
    'SERVER=MSOKIU;'
    'DATABASE=QLSinhVien;'
    'Trusted_Connection=yes;'
)

cursor = conn.cursor()
# Thực thi câu truy vấn SELECT
cursor.execute("SELECT * FROM SinhVien")
print('Danh sách sinh viên: ')

# Lấy dữ liệu và hiển thị
rows = cursor.fetchall()
for row in rows:
    print(f"ID: {row[0]}, Tên: {row[1]}, Lớp: {row[2]}")


# Đóng con trỏ
cursor.close()
